$(() => {
  // Select table containing the battleground
  const battleground = $('#battleground');

  // Build 10 x 10 grid for battleground
  for (let row = 0; row < 10; row++) {
    // Create table row
    const tr = $('<tr>');
    for (let column = 0; column < 10; column++) {
      // Create table cell with CSS class `water`. Note that we use
      // HTML data attributes  to store the coordinates of each cell
      // (see https://developer.mozilla.org/en-US/docs/Learn/HTML/Howto/Use_data_attributes). 
      // That makes it much easier to find cells based on coordinates later.
      $('<td>').addClass('water').attr('data-r', row).attr('data-c', column).appendTo(tr);
    }

    // Add table row to battleground table
    tr.appendTo(battleground);
  }

  $('#generate').click(() => {
    for(var i=0; i<10;i++){
      for(var j=0;j<10;j++){
        $('td[data-r='+i+'][data-c='+j+']').removeClass('ship').addClass('water');
      }
    }
    
  

    var dir =  Math.round(Math.random() * (3 - 1) + 1);
    var x = Math.round(Math.random() * (5 - 0) + 0);
    var y = Math.round(Math.random() * (5 - 0) + 0);
    var arr = [];
    
    for(var i=0; i<5; i++){
      if(dir === 1){
        x++;
      }else{
        y++;
      }
      arr.push((x*10)+y)
      $('td[data-r='+x+'][data-c='+y+']').removeClass('water').addClass('ship');
    }

    dir =  Math.round(Math.random() * (5 -  1) + 1);
    x = Math.round(Math.random() * (11 - 0) + 0);
    y = Math.round(Math.random() * (11 - 0) + 0);

    for(var i=0; i<4; i++){
      if(dir === 1){
        x++;
      }else if(dir === 2){
        x--;
      }else if(dir === 3){
        y++;
      }else{
        y--;
      }
      if(arr.find((x*10)+y) != undefined){
        arr.push((x*10)+y)
        $('td[data-r='+x+'][data-c='+y+']').removeClass('water').addClass('ship');
      }else{
        dir++;
        if(dir === 4 ){
          dir = 1;
        }
        i--;
      }
    }

    dir =  Math.round(Math.random() * (5 - 1) + 1);
    x = Math.round(Math.random() * (11 - 0) + 0);
    y = Math.round(Math.random() * (11 - 0) + 0);

    for(var i=0; i<3; i++){
      if(dir === 1){
        x++;
      }else if(dir === 2){
        x--;
      }else if(dir === 3){
        y++;
      }else{
        y--;
      }
      if(arr.find((x*10)+y) != undefined){
        arr.push((x*10)+y)
        $('td[data-r='+x+'][data-c='+y+']').removeClass('water').addClass('ship');
      }else{
        dir++;
        if(dir === 4 ){
          dir = 1;
        }
        i--;
      }
    }

    dir =  Math.round(Math.random() * (5 - 1) + 1);
    x = Math.round(Math.random() * (11 - 0) + 0);
    y = Math.round(Math.random() * (11 - 0) + 0);

    for(var i=0; i<3; i++){
      if(dir === 1){
        x++;
      }else if(dir === 2){
        x--;
      }else if(dir === 3){
        y++;
      }else{
        y--;
      }
      if(arr.find((x*10)+y) != undefined){
        arr.push((x*10)+y)
        $('td[data-r='+x+'][data-c='+y+']').removeClass('water').addClass('ship');
      }else{
        dir++;
        if(dir === 4 ){
          dir = 1;
        }
        i--;
      }
    }

    dir =  Math.round(Math.random() * (5 - 1) + 1);
    x = Math.round(Math.random() * (11 - 0) + 0);
    y = Math.round(Math.random() * (11 - 0) + 0);

    for(var i=0; i<2; i++){
      if(dir === 1){
        x++;
      }else if(dir === 2){
        x--;
      }else if(dir === 3){
        y++;
      }else{
        y--;
      }
      if(arr.find((x*10)+y) != undefined){
        arr.push((x*10)+y)
        $('td[data-r='+x+'][data-c='+y+']').removeClass('water').addClass('ship');
      }else{
        dir++;
        if(dir === 4 ){
          dir = 1;
        }
        i--;
      }
    }
    
      
      
  });
});